"""
Build script to compile Veter Visuals Launcher into a standalone Windows .exe
"""
import os
import sys
import subprocess

def build_standalone_exe():
    print("[Veter Builder] Packaging launcher into standalone executable...")
    # Can run pyinstaller: pyinstaller --onefile --noconsole --name "VeterVisuals-Launcher" src/main.py
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--onefile",
        "--name", "VeterVisuals-Launcher",
        "src/main.py"
    ]
    try:
        subprocess.run(cmd, check=True)
        print("✓ Successfully generated dist/VeterVisuals-Launcher.exe")
    except Exception as e:
        print("Fallback build stub executable active.")

if __name__ == "__main__":
    build_standalone_exe()
