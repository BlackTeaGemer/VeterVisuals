@echo off
title Build Veter Visuals Launcher .EXE
echo [1/3] Installing requirements...
pip install -r requirements.txt
echo [2/3] Building standalone executable...
pyinstaller --onefile --noconsole --name "VeterVisuals-Launcher" src/main.py
echo [3/3] Build finished! Executable is in dist/VeterVisuals-Launcher.exe
pause
