#!/bin/bash
echo "[Veter Launcher] Building standalone launcher binary..."
pip install -r requirements.txt
pyinstaller --onefile --name "VeterVisuals-Launcher" src/main.py
echo "✓ Finished! Binary created in dist/VeterVisuals-Launcher"
