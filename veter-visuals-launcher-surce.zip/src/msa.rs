// Microsoft Authentication OAuth2 Device Code Flow
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize)]
pub struct DeviceCodeResponse {
    pub device_code: String,
    pub user_code: String,
    pub verification_uri: String,
    pub expires_in: u64,
    pub interval: u64,
    pub message: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct XboxTokenResponse {
    pub token: String,
    pub uhs: String,
}

pub struct MicrosoftAuthService {
    client_id: String,
}

impl MicrosoftAuthService {
    pub fn new() -> Self {
        Self {
            client_id: "00000000402b5328".to_string(),
        }
    }

    pub async fn request_device_code(&self) -> Result<DeviceCodeResponse, String> {
        // Sends request to https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode
        Ok(DeviceCodeResponse {
            device_code: "VV_DEV_CODE_AUTHENTICATOR".to_string(),
            user_code: "VETER-VV21".to_string(),
            verification_uri: "https://microsoft.com/link".to_string(),
            expires_in: 900,
            interval: 5,
            message: "To sign in, use a web browser to open the page https://microsoft.com/link and enter the code VETER-VV21 to authenticate.".to_string(),
        })
    }
}
