// Instance and JVM arguments management
use std::path::PathBuf;

pub struct InstanceManager {
    base_dir: PathBuf,
}

impl InstanceManager {
    pub fn new(base_dir: PathBuf) -> Self {
        Self { base_dir }
    }

    pub fn get_instance_dir(&self, version: &str) -> PathBuf {
        self.base_dir.join("instances").join(version)
    }

    pub fn build_jvm_args(&self, ram_gb: u32, version: &str) -> Vec<String> {
        vec![
            format!("-Xms{}G", ram_gb),
            format!("-Xmx{}G", ram_gb),
            "-XX:+UseG1GC".to_string(),
            "-XX:+ParallelRefProcEnabled".to_string(),
            "-XX:MaxGCPauseMillis=10".to_string(),
            "-XX:+UnlockExperimentalVMOptions".to_string(),
            "-XX:+AlwaysPreTouch".to_string(),
            "-XX:G1NewSizePercent=25".to_string(),
            "-XX:G1MaxNewSizePercent=40".to_string(),
            format!("-Dvetervisuals.version=2.1.0"),
            format!("-Dvetervisuals.target_mc={}", version),
        ]
    }
}
