// Veter Visuals Launcher Core (Rust Native)
mod msa;
mod rpc;
mod instance;
mod install;

use std::sync::Arc;
use tokio::sync::Mutex;

#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct LauncherConfig {
    pub selected_version: String,
    pub allocated_ram_gb: u32,
    pub discord_rpc_enabled: bool,
    pub jvm_profile: String,
}

impl Default for LauncherConfig {
    fn default() -> Self {
        Self {
            selected_version: "1.21.4".to_string(),
            allocated_ram_gb: 4,
            discord_rpc_enabled: true,
            jvm_profile: "Aikar-G1GC".to_string(),
        }
    }
}

#[tokio::main]
async fn main() {
    println!("=======================================================");
    println!(" Veter Visuals Native Engine Launcher v2.1.0 (Rust)   ");
    println!("=======================================================");

    let rpc_client = Arc::new(Mutex::new(rpc::DiscordRpcBridge::new("1214002938491029384")));
    if let Ok(mut client) = rpc_client.try_lock() {
        let _ = client.connect().await;
        let _ = client.update_activity("1.21.4", "veter.network", 3, 4).await;
    }

    println!("[Launcher] Ready. Standalone native engine ready for execution.");
}
