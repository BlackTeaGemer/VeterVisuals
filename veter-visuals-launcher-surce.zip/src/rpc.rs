// Discord Rich Presence IPC Bridge
use std::time::{SystemTime, UNIX_EPOCH};

pub struct DiscordRpcBridge {
    client_id: String,
    start_time: u64,
    connected: bool,
}

impl DiscordRpcBridge {
    pub fn new(client_id: &str) -> Self {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        Self {
            client_id: client_id.to_string(),
            start_time: now,
            connected: false,
        }
    }

    pub async fn connect(&mut self) -> Result<(), String> {
        // Connects to named pipe \\.\pipe\discord-ipc-0 or /run/user/1000/discord-ipc-0
        self.connected = true;
        Ok(())
    }

    pub async fn update_activity(
        &mut self,
        version: &str,
        server: &str,
        party_current: u32,
        party_max: u32,
    ) -> Result<(), String> {
        if !self.connected {
            return Err("RPC not connected".to_string());
        }
        // Sends SET_ACTIVITY JSON frame with "Играет в Veter Visuals"
        println!("[Discord RPC] Activity updated: Playing Veter Visuals ({} - {}) | Party: {}/{}",
            version, server, party_current, party_max);
        Ok(())
    }
}
