# 🚀 Veter Visuals — Desktop Launcher Source Code

Исходный код автономного лаунчера **Veter Visuals 2.1.0** (Python + Rust Tauri + Native IPC).

---

## 📁 Структура проекта:

```
launcher-sources/
├── Cargo.toml                  # Конфигурация Rust ядра лаунчера
├── requirements.txt            # Python зависимости
├── build.bat / build.sh        # Скрипты компиляции в .exe
├── build_exe.py                # Генератор бинарника PyInstaller
└── src/
    ├── main.py                 # Главный Python лаунчер (GUI + CLI + JVM Manager)
    ├── main.rs                 # Rust Native точка входа
    ├── msa.rs                  # Microsoft OAuth 2.0 Device Code Flow
    ├── rpc.rs                  # Discord IPC сокет («Играет в Veter Visuals»)
    ├── instance.rs             # Менеджер изолированных инстансов и JVM-флагов
    └── install.rs              # Загрузчик метаданных Fabric Loader
```

---

## 🛠️ Как запустить и собрать:

### Быстрый запуск в режиме разработки:
```bash
python3 src/main.py --launch 1.21.4
```

### Сборка в автономный `.exe` для Windows:
Запустите `build.bat` или выполните:
```bash
pip install -r requirements.txt
pyinstaller --onefile --noconsole --name "VeterVisuals-Launcher" src/main.py
```
Готовый файл `VeterVisuals-Launcher.exe` появится в папке `dist/`.

### Сборка нативного Rust движка:
```bash
cargo build --release
```
