@echo off
title Veter Visuals Launcher 2.1.0
python main.py %*
pause
