# ⚡ Veter Visuals — Fabric Mod Source Code (1.16.5 / 1.21.4 / 1.21.11)

Исходный код ядра клиента **Veter Visuals 2.1.0** для Fabric Loader.

---

## 📁 Структура проекта:

```
mod-sources/
├── build.gradle                              # Конфигурация Fabric Loom 1.7
├── gradle.properties                         # Версии Minecraft (1.21.4), Loader и Mod
├── gradlew / gradlew.bat                     # Gradle Wrapper
└── src/
    └── main/
        ├── java/net/vetervisuals/
        │   ├── core/
        │   │   └── VeterClient.java          # Главная точка входа (ClientModInitializer)
        │   ├── render/
        │   │   ├── HudBatcher.java           # Батчинг вершинных буферов (1 draw call)
        │   │   ├── GlyphCache.java           # LRU-кэш измерений глифов и строк
        │   │   ├── DirtyFlagHud.java         # Dirty-флаги для исключения перерисовки
        │   │   ├── FramePacer.java           # Выравнивание фреймтайма (Frame Pacing)
        │   │   └── RenderBudget.java         # Бюджетирование времени рендера кадра
        │   ├── tab/
        │   │   └── BadgeRenderer.java        # Рендерер анимированных бейджей [VV] в Табе
        │   ├── rpc/
        │   │   └── DiscordBridge.java        # Нативный мост Discord Rich Presence (IPC)
        │   ├── config/
        │   │   └── VeterConfig.java          # Асинхронное сохранение config/veter.json
        │   ├── modules/
        │   │   ├── DamageNumbers.java        # Всплывающие цифры урона (-7.5 / CRIT)
        │   │   ├── CustomHitColor.java       # Кастомный цвет вспышки при ударе (RGBA)
        │   │   ├── CustomCrosshair.java      # Кастомные стили прицела (Cyber Cross / Dot)
        │   │   ├── KeystrokesModule.java     # Модуль клавиш WASD + CPS
        │   │   ├── ArmorStatusModule.java    # Индикатор прочности брони в %
        │   │   └── PotionHudModule.java      # Таймеры активных эффектов зелий
        │   └── mixin/
        │       ├── PlayerListHudMixin.java   # Инъекция значка VV в Таб-лист
        │       └── InGameHudMixin.java       # Перехват и батчинг отрисовки HUD
        └── resources/
            ├── fabric.mod.json               # Манифест мода Fabric
            └── vetervisuals.mixins.json      # Конфигурация Mixin
```

---

## 🛠️ Как скомпилировать .jar файл:

### В IntelliJ IDEA / Eclipse / VS Code:
1. Откройте папку `mod-sources` как проект Gradle.
2. Справа в панели Gradle откройте **Tasks → build → build** (или `jar`).
3. Скомпилированный `.jar` появится в папке `build/libs/`.

### Через командную строку (Терминал):
```bash
# Linux / macOS:
./gradlew build

# Windows:
gradlew.bat build
```

---

## 🔄 Как переключить версию Minecraft (1.16.5, 1.21.4, 1.21.11):
В файле `gradle.properties` измените целевую версию:
```properties
minecraft_version=1.21.4        # или 1.16.5 / 1.21.11
yarn_mappings=1.21.4+build.3
loader_version=0.16.10
fabric_version=0.114.0+1.21.4
```
И выполните `./gradlew build`.
