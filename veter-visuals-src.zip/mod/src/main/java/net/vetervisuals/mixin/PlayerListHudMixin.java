package net.vetervisuals.mixin;

import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.vetervisuals.core.VeterClient;
import net.vetervisuals.tab.BadgeRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin for PlayerListHud (Minecraft Tab-list)
 * Renders the custom stylized [VV] badge to the left of players running Veter Visuals.
 */
@Mixin(PlayerListHud.class)
public class PlayerListHudMixin {

    @Inject(method = "renderLatencyIcon", at = @At("HEAD"))
    private void onRenderLatencyIcon(MatrixStack matrices, int width, int x, int y, PlayerListEntry entry, CallbackInfo ci) {
        if (entry == null || entry.getProfile() == null) return;

        VeterClient client = VeterClient.getInstance();
        if (client == null || !client.getConfig().tabBadgesEnabled) return;

        BadgeRenderer badgeRenderer = client.getBadgeRenderer();
        if (badgeRenderer != null && badgeRenderer.isVeterUser(entry.getProfile().getId(), entry.getProfile().getName())) {
            // Draw VV badge to the left of the player's name
            float animPhase = (System.currentTimeMillis() % 2000L) / 2000.0f;
            BadgeRenderer.BadgeStyle style = BadgeRenderer.BadgeStyle.valueOf(client.getConfig().badgeStyle);
            badgeRenderer.renderBadge(client.getHudBatcher(), x - 12, y + 1, style, animPhase);
        }
    }
}
