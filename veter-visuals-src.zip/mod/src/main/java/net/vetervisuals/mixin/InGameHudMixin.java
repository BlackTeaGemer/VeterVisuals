package net.vetervisuals.mixin;

import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.util.math.MatrixStack;
import net.vetervisuals.core.VeterClient;
import net.vetervisuals.render.HudBatcher;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin for InGameHud
 * Intercepts vanilla HUD rendering and integrates the Veter Visuals Dirty-Flag Batched HUD pipeline.
 */
@Mixin(InGameHud.class)
public class InGameHudMixin {

    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderHudHead(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        VeterClient client = VeterClient.getInstance();
        if (client == null) return;

        // Start Frame Pacing and Render Budgeting
        client.getFramePacer().onFrameStart();
        client.getRenderBudget().beginFrame();

        // Begin batched HUD drawing
        HudBatcher batcher = client.getHudBatcher();
        if (batcher != null) {
            batcher.begin();
        }
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void onRenderHudTail(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        VeterClient client = VeterClient.getInstance();
        if (client == null) return;

        // Flush all batched quads in a single OpenGL draw call
        HudBatcher batcher = client.getHudBatcher();
        if (batcher != null) {
            batcher.endAndFlush();
        }
    }
}
