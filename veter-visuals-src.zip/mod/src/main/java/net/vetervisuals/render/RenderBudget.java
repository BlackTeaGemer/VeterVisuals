package net.vetervisuals.render;

/**
 * RenderBudget - Allocates time budgets (in milliseconds) for optional cosmetic subsystems.
 * If animations, particles, or complex HUD rendering exceed the frame budget,
 * non-essential visual recalculations are gracefully deferred to avoid dropping frames.
 */
public class RenderBudget {
    private final float maxFrameBudgetMs;
    private long frameStartNano;

    public RenderBudget(float maxFrameBudgetMs) {
        this.maxFrameBudgetMs = maxFrameBudgetMs;
    }

    public void beginFrame() {
        this.frameStartNano = System.nanoTime();
    }

    public boolean hasBudget(float estimatedSubsystemTimeMs) {
        long elapsedNano = System.nanoTime() - frameStartNano;
        float elapsedMs = elapsedNano / 1_000_000.0f;
        return (elapsedMs + estimatedSubsystemTimeMs) <= maxFrameBudgetMs;
    }

    public float getElapsedFrameTimeMs() {
        return (System.nanoTime() - frameStartNano) / 1_000_000.0f;
    }
}
