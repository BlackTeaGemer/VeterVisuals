package net.vetervisuals.render;

/**
 * FramePacer - Smooths frametimes by pacing render execution.
 * Reduces micro-stuttering and stabilizes the 1% low FPS.
 */
public class FramePacer {
    private long lastFrameTimeNano = System.nanoTime();
    private long targetFrameDurationNano = 1_000_000_000L / 144; // Default 144 Hz
    private float smoothDeltaTime = 0.016f;

    public void setTargetFps(int fps) {
        if (fps <= 0) {
            this.targetFrameDurationNano = 0; // Uncapped
        } else {
            this.targetFrameDurationNano = 1_000_000_000L / fps;
        }
    }

    public void onFrameStart() {
        long now = System.nanoTime();
        long delta = now - lastFrameTimeNano;
        lastFrameTimeNano = now;

        // Exponential moving average for smooth animation interpolations
        float rawDelta = delta / 1_000_000_000.0f;
        smoothDeltaTime = smoothDeltaTime * 0.9f + rawDelta * 0.1f;
    }

    public float getSmoothDeltaTime() {
        return smoothDeltaTime;
    }
}
