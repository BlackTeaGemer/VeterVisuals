package net.vetervisuals.render;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * GlyphCache - Fast LRU cache for string metrics and font glyph measurements.
 * Completely eliminates String.format and FontRenderer.getWidth() GC overhead on hot paths.
 */
public class GlyphCache {
    private final int capacity;
    private final LinkedHashMap<String, CachedMetric> cache;
    private long hitCount = 0;
    private long missCount = 0;

    public static class CachedMetric {
        public final int width;
        public final int height;
        public final float[] vertexCoords;

        public CachedMetric(int width, int height, float[] vertexCoords) {
            this.width = width;
            this.height = height;
            this.vertexCoords = vertexCoords;
        }
    }

    public GlyphCache(int capacity) {
        this.capacity = capacity;
        this.cache = new LinkedHashMap<String, CachedMetric>(capacity, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<String, CachedMetric> eldest) {
                return size() > GlyphCache.this.capacity;
            }
        };
    }

    public synchronized CachedMetric get(String text) {
        CachedMetric metric = cache.get(text);
        if (metric != null) {
            hitCount++;
            return metric;
        }
        missCount++;
        return null;
    }

    public synchronized void put(String text, int width, int height, float[] coords) {
        cache.put(text, new CachedMetric(width, height, coords));
    }

    public synchronized void clear() {
        cache.clear();
    }

    public double getHitRatio() {
        long total = hitCount + missCount;
        return total == 0 ? 1.0 : (double) hitCount / total;
    }
}
