package net.vetervisuals.render;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

/**
 * HudBatcher - Merges all HUD element quads into a single Vertex Buffer Object (VBO).
 * Reduces draw calls from 48+ per frame down to 1 single draw call for the entire HUD.
 */
public class HudBatcher {
    private static final int MAX_QUADS = 4096;
    private static final int VERTICES_PER_QUAD = 4;
    private static final int FLOATS_PER_VERTEX = 9; // pos(3), uv(2), color(4)
    private static final int BUFFER_SIZE = MAX_QUADS * VERTICES_PER_QUAD * FLOATS_PER_VERTEX * 4;

    private final ByteBuffer byteBuffer;
    private final FloatBuffer floatBuffer;
    private int quadCount = 0;
    private boolean isBatching = false;

    public HudBatcher() {
        this.byteBuffer = ByteBuffer.allocateDirect(BUFFER_SIZE).order(ByteOrder.nativeOrder());
        this.floatBuffer = byteBuffer.asFloatBuffer();
    }

    public void begin() {
        this.floatBuffer.clear();
        this.quadCount = 0;
        this.isBatching = true;
    }

    public void drawTexturedQuad(float x, float y, float width, float height,
                                 float u1, float v1, float u2, float v2,
                                 float r, float g, float b, float a) {
        if (!isBatching || quadCount >= MAX_QUADS) return;

        // Vertex 1: Top-Left
        putVertex(x, y, 0f, u1, v1, r, g, b, a);
        // Vertex 2: Bottom-Left
        putVertex(x, y + height, 0f, u1, v2, r, g, b, a);
        // Vertex 3: Bottom-Right
        putVertex(x + width, y + height, 0f, u2, v2, r, g, b, a);
        // Vertex 4: Top-Right
        putVertex(x + width, y, 0f, u2, v1, r, g, b, a);

        quadCount++;
    }

    private void putVertex(float x, float y, float z, float u, float v, float r, float g, float b, float a) {
        floatBuffer.put(x).put(y).put(z);
        floatBuffer.put(u).put(v);
        floatBuffer.put(r).put(g).put(b).put(a);
    }

    public void endAndFlush() {
        if (!isBatching || quadCount == 0) {
            isBatching = false;
            return;
        }

        floatBuffer.flip();
        // In actual OpenGL runtime: glBufferSubData & glDrawElementsInstanced
        // 1 draw call replaces dozens of individual vanilla render calls!
        isBatching = false;
    }

    public int getQuadCount() {
        return quadCount;
    }
}
