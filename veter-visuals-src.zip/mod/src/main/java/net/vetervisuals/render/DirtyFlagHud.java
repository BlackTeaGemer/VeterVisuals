package net.vetervisuals.render;

import java.util.HashMap;
import java.util.Map;

/**
 * DirtyFlagHud - Manages state versioning for individual HUD modules.
 * If CPS, FPS, Keystrokes, or Armor status haven't changed since the previous frame,
 * the renderer skips re-computation and re-upload entirely.
 */
public class DirtyFlagHud {
    private final Map<String, Long> stateVersions = new HashMap<>();
    private final Map<String, Long> renderedVersions = new HashMap<>();

    public void markDirty(String moduleId) {
        long current = stateVersions.getOrDefault(moduleId, 0L);
        stateVersions.put(moduleId, current + 1);
    }

    public boolean shouldRender(String moduleId) {
        long currentVersion = stateVersions.getOrDefault(moduleId, 0L);
        long lastRendered = renderedVersions.getOrDefault(moduleId, -1L);
        return currentVersion != lastRendered;
    }

    public void markRendered(String moduleId) {
        long currentVersion = stateVersions.getOrDefault(moduleId, 0L);
        renderedVersions.put(moduleId, currentVersion);
    }

    public void forceAllDirty() {
        for (String key : stateVersions.keySet()) {
            stateVersions.put(key, stateVersions.get(key) + 1);
        }
    }
}
