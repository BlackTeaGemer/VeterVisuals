package net.vetervisuals.core;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.vetervisuals.config.VeterConfig;
import net.vetervisuals.render.HudBatcher;
import net.vetervisuals.render.GlyphCache;
import net.vetervisuals.render.DirtyFlagHud;
import net.vetervisuals.render.FramePacer;
import net.vetervisuals.render.RenderBudget;
import net.vetervisuals.rpc.DiscordBridge;
import net.vetervisuals.tab.BadgeRenderer;
import net.vetervisuals.modules.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Veter Visuals Core Engine
 * Ultra-optimized, fair-play visual client for Fabric Minecraft (1.16.5, 1.21.4, 1.21.11)
 * 
 * Features:
 * - Zero Unfair Advantage (No reach, No fastswap, No ESP, No X-Ray, No AutoClicker)
 * - Dirty-Flag HUD Engine (0 draw-calls on unchanged frames)
 * - Single Atlas HUD Batching
 * - LRU Glyph & String Width Cache
 * - Native Discord Rich Presence ("Playing Veter Visuals")
 * - Dynamic Tab-List VV Badges for Veter Visuals users
 */
@Environment(EnvType.CLIENT)
public class VeterClient implements ClientModInitializer {
    public static final String MOD_ID = "vetervisuals";
    public static final String MOD_NAME = "Veter Visuals";
    public static final String VERSION = "2.1.0";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_NAME);

    private static VeterClient instance;
    private VeterConfig config;
    private HudBatcher hudBatcher;
    private GlyphCache glyphCache;
    private DirtyFlagHud dirtyFlagHud;
    private FramePacer framePacer;
    private RenderBudget renderBudget;
    private BadgeRenderer badgeRenderer;
    private DiscordBridge discordBridge;

    // Visual Modules
    private DamageNumbers damageNumbers;
    private CustomHitColor customHitColor;
    private CustomCrosshair customCrosshair;
    private KeystrokesModule keystrokesModule;
    private ArmorStatusModule armorStatusModule;
    private PotionHudModule potionHudModule;

    @Override
    public void onInitializeClient() {
        instance = this;
        LOGGER.info("[Veter Visuals] Initializing Core Engine v{}...", VERSION);

        // 1. Load Configuration
        this.config = VeterConfig.load();

        // 2. Initialize Core Performance Systems
        this.glyphCache = new GlyphCache(1024);
        this.hudBatcher = new HudBatcher();
        this.dirtyFlagHud = new DirtyFlagHud();
        this.renderBudget = new RenderBudget(16.6f); // 60-144fps pacing budget
        this.framePacer = new FramePacer();

        // 3. Initialize Visual Enhancements
        this.badgeRenderer = new BadgeRenderer();
        this.damageNumbers = new DamageNumbers();
        this.customHitColor = new CustomHitColor();
        this.customCrosshair = new CustomCrosshair();
        this.keystrokesModule = new KeystrokesModule();
        this.armorStatusModule = new ArmorStatusModule();
        this.potionHudModule = new PotionHudModule();

        // 4. Initialize Discord Rich Presence in background thread
        if (config.discordRpcEnabled) {
            this.discordBridge = new DiscordBridge();
            this.discordBridge.start();
        }

        LOGGER.info("[Veter Visuals] Engine initialized successfully with 0 allocation pipeline!");
    }

    public static VeterClient getInstance() {
        return instance;
    }

    public VeterConfig getConfig() {
        return config;
    }

    public HudBatcher getHudBatcher() {
        return hudBatcher;
    }

    public GlyphCache getGlyphCache() {
        return glyphCache;
    }

    public DirtyFlagHud getDirtyFlagHud() {
        return dirtyFlagHud;
    }

    public FramePacer getFramePacer() {
        return framePacer;
    }

    public RenderBudget getRenderBudget() {
        return renderBudget;
    }

    public BadgeRenderer getBadgeRenderer() {
        return badgeRenderer;
    }

    public DiscordBridge getDiscordBridge() {
        return discordBridge;
    }

    public DamageNumbers getDamageNumbers() {
        return damageNumbers;
    }

    public CustomHitColor getCustomHitColor() {
        return customHitColor;
    }

    public CustomCrosshair getCustomCrosshair() {
        return customCrosshair;
    }

    public KeystrokesModule getKeystrokesModule() {
        return keystrokesModule;
    }

    public ArmorStatusModule getArmorStatusModule() {
        return armorStatusModule;
    }

    public PotionHudModule getPotionHudModule() {
        return potionHudModule;
    }
}
