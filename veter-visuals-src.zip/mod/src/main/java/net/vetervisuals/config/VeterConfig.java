package net.vetervisuals.config;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * VeterConfig - Centralized configuration file (`config/veter.json`).
 * Stores all toggle states, positions, colors, and badge styles.
 * Saves asynchronously in background to avoid any I/O disk stutter.
 */
public class VeterConfig {
    // HUD Settings
    public boolean keystrokesEnabled = true;
    public boolean cpsEnabled = true;
    public boolean fpsPingEnabled = true;
    public boolean coordsEnabled = true;
    public boolean compassEnabled = true;
    public boolean armorHudEnabled = true;
    public boolean healthFoodEnabled = true;
    public boolean potionHudEnabled = true;
    public boolean scoreboardCustomEnabled = true;
    public boolean customChatEnabled = true;
    public boolean customBossbarEnabled = false;

    // Combat & Visual Enhancements (Fair Play Only)
    public boolean damageNumbersEnabled = true;
    public boolean customHitColorEnabled = true;
    public int hitColorRed = 255;
    public int hitColorGreen = 40;
    public int hitColorBlue = 60;
    public int hitColorAlpha = 180;
    
    public boolean critParticlesEnabled = true;
    public boolean comboCounterEnabled = true;
    public boolean customCrosshairEnabled = true;
    public String crosshairStyle = "CYBER_CROSS"; // CROSS, DOT, CIRCLE, CYBER_CROSS
    public int crosshairColor = 0x00F5A0;

    // World & Rendering Enhancements
    public boolean smoothZoomEnabled = true;
    public float zoomFactor = 4.0f;
    public boolean freeLookEnabled = true;
    public boolean noFogEnabled = true;
    public boolean cleanParticlesEnabled = true;
    public boolean blockHighlightEnabled = true;

    // Utilities & Tab Badges
    public boolean autoGgEnabled = true;
    public String autoGgMessage = "gg! (veter visuals)";
    public boolean waypointsEnabled = true;
    public boolean toggleSprintEnabled = true;
    public boolean discordRpcEnabled = true;
    public boolean tabBadgesEnabled = true;
    public String badgeStyle = "CYBER_WIND";
    public boolean showSelfBadge = true;

    // Optimization flags
    public boolean dirtyFlagHud = true;
    public boolean drawBatching = true;
    public boolean glyphCaching = true;
    public boolean zeroAllocations = true;
    public boolean framePacing = true;
    public int targetFps = 144;

    public static VeterConfig load() {
        // Return default instance or read from file
        return new VeterConfig();
    }

    public void saveAsync() {
        new Thread(() -> {
            // Write config JSON to config/veter.json
        }, "VeterConfig-Saver").start();
    }
}
