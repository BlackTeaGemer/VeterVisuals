package net.vetervisuals.modules;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * DamageNumbers - Smooth floating cosmetic damage indicators above hit entities.
 * Features customizable font, neon color gradient based on crit, and bouncy physics.
 */
public class DamageNumbers {
    public static class Particle {
        public double x, y, z;
        public double motionY;
        public float damage;
        public boolean isCrit;
        public int age;
        public int maxAge = 25;

        public Particle(double x, double y, double z, float damage, boolean isCrit) {
            this.x = x + (Math.random() - 0.5) * 0.4;
            this.y = y + 0.5;
            this.z = z + (Math.random() - 0.5) * 0.4;
            this.motionY = 0.08;
            this.damage = damage;
            this.isCrit = isCrit;
            this.age = 0;
        }

        public void tick() {
            y += motionY;
            motionY *= 0.92;
            age++;
        }

        public float getAlpha() {
            return 1.0f - ((float) age / maxAge);
        }
    }

    private final List<Particle> particles = new ArrayList<>();

    public void spawnDamage(double x, double y, double z, float damage, boolean isCrit) {
        particles.add(new Particle(x, y, z, damage, isCrit));
    }

    public void tick() {
        Iterator<Particle> it = particles.iterator();
        while (it.hasNext()) {
            Particle p = it.next();
            p.tick();
            if (p.age >= p.maxAge) {
                it.remove();
            }
        }
    }

    public List<Particle> getParticles() {
        return particles;
    }
}
