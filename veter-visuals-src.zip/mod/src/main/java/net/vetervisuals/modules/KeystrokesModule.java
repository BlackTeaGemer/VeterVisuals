package net.vetervisuals.modules;

import java.util.LinkedList;

/**
 * KeystrokesModule - WASD keys + Mouse LMB/RMB status with live CPS calculator.
 */
public class KeystrokesModule {
    private final LinkedList<Long> lmbClicks = new LinkedList<>();
    private final LinkedList<Long> rmbClicks = new LinkedList<>();

    public boolean wPressed = false;
    public boolean aPressed = false;
    public boolean sPressed = false;
    public boolean dPressed = false;
    public boolean spacePressed = false;
    public boolean lmbPressed = false;
    public boolean rmbPressed = false;

    public void recordLmb() {
        long now = System.currentTimeMillis();
        lmbClicks.add(now);
        lmbPressed = true;
    }

    public void recordRmb() {
        long now = System.currentTimeMillis();
        rmbClicks.add(now);
        rmbPressed = true;
    }

    public int getLmbCps() {
        long cutoff = System.currentTimeMillis() - 1000L;
        lmbClicks.removeIf(time -> time < cutoff);
        return lmbClicks.size();
    }

    public int getRmbCps() {
        long cutoff = System.currentTimeMillis() - 1000L;
        rmbClicks.removeIf(time -> time < cutoff);
        return rmbClicks.size();
    }
}
