package net.vetervisuals.modules;

/**
 * CustomHitColor - Allows customizing the red damage tint flash when hitting or taking damage.
 * Supports custom RGB colors, glow intensity, and customizable flash duration.
 */
public class CustomHitColor {
    public float red = 1.0f;
    public float green = 0.15f;
    public float blue = 0.35f;
    public float alpha = 0.7f;
    public boolean enabled = true;

    public void setColor(int r, int g, int b, int a) {
        this.red = r / 255.0f;
        this.green = g / 255.0f;
        this.blue = b / 255.0f;
        this.alpha = a / 255.0f;
    }

    public int getCombinedColor() {
        int r = (int) (red * 255);
        int g = (int) (green * 255);
        int b = (int) (blue * 255);
        int a = (int) (alpha * 255);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
