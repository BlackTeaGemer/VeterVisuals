package net.vetervisuals.modules;

import java.util.ArrayList;
import java.util.List;

/**
 * PotionHudModule - Sleek active potion effects display with animated duration countdown bars.
 */
public class PotionHudModule {
    public static class ActiveEffect {
        public String name;
        public int amplifier;
        public int durationTicks;
        public int colorRgb;

        public ActiveEffect(String name, int amplifier, int durationTicks, int colorRgb) {
            this.name = name;
            this.amplifier = amplifier;
            this.durationTicks = durationTicks;
            this.colorRgb = colorRgb;
        }

        public String getFormattedDuration() {
            int seconds = (durationTicks / 20) % 60;
            int minutes = (durationTicks / 20) / 60;
            return String.format("%d:%02d", minutes, seconds);
        }
    }

    public boolean compactMode = false;
    public boolean showIcon = true;
    public boolean showDurationBar = true;
}
