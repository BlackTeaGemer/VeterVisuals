package net.vetervisuals.modules;

import java.util.ArrayList;
import java.util.List;

/**
 * ArmorStatusModule - Displays equipped Helmet, Chestplate, Leggings, Boots, and Held Item
 * with color-coded durability bars and exact percentages.
 */
public class ArmorStatusModule {
    public static class ArmorItem {
        public String name;
        public int currentDurability;
        public int maxDurability;
        public float damagePercent;

        public ArmorItem(String name, int currentDurability, int maxDurability) {
            this.name = name;
            this.currentDurability = currentDurability;
            this.maxDurability = maxDurability;
            this.damagePercent = (float) currentDurability / Math.max(1, maxDurability);
        }
    }

    public boolean showDurabilityPercentage = true;
    public boolean showItemDamageCount = true;
    public boolean horizontalLayout = false;
    public float scale = 1.0f;
}
