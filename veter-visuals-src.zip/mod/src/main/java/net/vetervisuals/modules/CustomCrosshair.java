package net.vetervisuals.modules;

/**
 * CustomCrosshair - Replaces the default crosshair with sleek customizable reticles:
 * - Dynamic blooming crosshair
 * - Minimal dot
 * - Cyber circle with dot
 * - VV Cyber Cross
 */
public class CustomCrosshair {
    public enum Style {
        DEFAULT,
        CROSS,
        DOT,
        CIRCLE_DOT,
        CYBER_CROSS,
        CHEVRON
    }

    public Style style = Style.CYBER_CROSS;
    public int size = 6;
    public int gap = 3;
    public int thickness = 2;
    public boolean dynamicBloom = true;
    public boolean rainbowChroma = false;
    public int color = 0x00F5A0; // Neon Mint
    public boolean outline = true;
}
