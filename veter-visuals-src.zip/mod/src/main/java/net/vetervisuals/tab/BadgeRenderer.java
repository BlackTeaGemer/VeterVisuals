package net.vetervisuals.tab;

import net.vetervisuals.core.VeterClient;
import net.vetervisuals.render.HudBatcher;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * BadgeRenderer - Renders custom stylized VV badges in the Tab Player List.
 * Identifies players also running Veter Visuals via metadata/network handshake
 * and draws the special glowing VV icon directly to the left of their username.
 */
public class BadgeRenderer {
    // Set of known Veter Visuals users on current server
    private final Set<UUID> veterUsers = new HashSet<>();
    private final Set<String> veterUsernames = new HashSet<>();

    public enum BadgeStyle {
        CYBER_WIND("Cyber Wind", 0, 0),
        NEON_SHIELD("Neon Shield", 32, 0),
        HOLO_MONO("Holographic Mono", 64, 0),
        RETRO_PIXEL("Retro Pixel", 96, 0),
        QUANTUM_RING("Quantum Ring", 128, 0);

        private final String displayName;
        private final int atlasU;
        private final int atlasV;

        BadgeStyle(String displayName, int atlasU, int atlasV) {
            this.displayName = displayName;
            this.atlasU = atlasU;
            this.atlasV = atlasV;
        }

        public String getDisplayName() {
            return displayName;
        }

        public int getAtlasU() {
            return atlasU;
        }

        public int getAtlasV() {
            return atlasV;
        }
    }

    public BadgeRenderer() {
        // Register local player by default
        veterUsernames.add("Veter");
        veterUsernames.add("Player");
    }

    public void registerVeterUser(UUID uuid, String username) {
        if (uuid != null) veterUsers.add(uuid);
        if (username != null) veterUsernames.add(username.toLowerCase());
    }

    public void unregisterVeterUser(UUID uuid, String username) {
        if (uuid != null) veterUsers.remove(uuid);
        if (username != null) veterUsernames.remove(username.toLowerCase());
    }

    public boolean isVeterUser(UUID uuid, String username) {
        if (uuid != null && veterUsers.contains(uuid)) return true;
        if (username != null && veterUsernames.contains(username.toLowerCase())) return true;
        return false;
    }

    /**
     * Renders the stylized VV badge into the HUD batch buffer
     * 
     * @param x Screen X coordinate
     * @param y Screen Y coordinate
     * @param style Selected badge visual design
     * @param pulseAnimation Current animation phase (0.0 to 1.0)
     */
    public void renderBadge(HudBatcher batcher, float x, float y, BadgeStyle style, float pulseAnimation) {
        if (batcher == null) return;

        float u1 = style.getAtlasU() / 256.0f;
        float v1 = style.getAtlasV() / 256.0f;
        float u2 = (style.getAtlasU() + 24) / 256.0f;
        float v2 = (style.getAtlasV() + 24) / 256.0f;

        // Subtle cyan-emerald neon glow pulsation
        float alpha = 0.85f + 0.15f * (float) Math.sin(pulseAnimation * Math.PI * 2);
        float r = 0.0f;
        float g = 0.96f; // #00f5a0 neon mint
        float b = 0.65f;

        // Draw 10x10 or 12x12 badge quad
        batcher.drawTexturedQuad(x, y - 1, 10, 10, u1, v1, u2, v2, r, g, b, alpha);
    }
}
