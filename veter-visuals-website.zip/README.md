# 🌐 Veter Visuals — Готовый сайт для бесплатного хостинга

Этот репозиторий/архив содержит **100% готовый статический сайт Veter Visuals 2.1.0** со встроенными скачиваемыми файлами (`.exe`, `.jar`, `.zip`), интерактивным симулятором HUD, бенчмарком и проводником кода.

---

## 🚀 3 Способа запустить этот сайт бесплатно навсегда:

### 1. GitHub Pages (Самый простой и популярный, 100% бесплатно)
1. Создайте новый бесплатный репозиторий на [GitHub.com](https://github.com/) (например, `veter-visuals-site`).
2. Загрузите в него все файлы из этой папки (или распакуйте архив `veter-visuals-website.zip`).
3. Перейдите в **Settings** репозитория → вкладка **Pages** (слева).
4. В разделе **Build and deployment** выберите **Source: Deploy from a branch** (или GitHub Actions) и укажите ветку `main` / root `/`.
5. Нажмите **Save**. Через 30 секунд ваш сайт будет доступен по адресу `https://ваш-ник.github.io/veter-visuals-site/`!

### 2. Vercel (Мгновенный деплой в 1 клик)
1. Зайдите на [Vercel.com](https://vercel.com) через аккаунт GitHub.
2. Нажмите **Add New... → Project**.
3. Выберите ваш репозиторий с файлами сайта.
4. Нажмите **Deploy**.
5. Вы мгновенно получите бесплатный защищённый HTTPS-домен вида `https://veter-visuals.vercel.app`.

### 3. Netlify (Drag & Drop без Git)
1. Зайдите на [Netlify.com](https://www.netlify.com).
2. Перейдите на вкладку **Sites** и просто **перетащите мышкой папку с сайтом** в поле *«Drag and drop your site output folder here»*.
3. Сайт опубликуется за 5 секунд с бесплатным доменом `https://...netlify.app`.

---

## 📦 Включенные файлы в сайт:
* `index.html` — Главная страница лаунчера и клиента
* `style.css` — Кибер-оформление в стиле `01a10276-51c0-7d4e-8778-f997b8c40a34.arena.site`
* `app.js` — Логика симулятора, звуковой движок, бенчмарк, проводник кода
* `downloads/` — Все готовые файлы для скачивания пользователями:
  * `veter-visuals-full-bundle.zip`
  * `VeterVisuals-Launcher.exe`
  * `veter-visuals-1.21.4-fabric.jar`
  * `veter-visuals-1.16.5-fabric.jar`
  * `veter-visuals-1.21.11-fabric.jar`
  * `veter-visuals-src.zip`
